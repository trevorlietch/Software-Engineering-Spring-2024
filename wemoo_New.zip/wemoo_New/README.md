# Wemoo App
Realtime chat app with websockets using Node.js, Express and Socket.io with Vanilla JS on the frontend with a custom UI

## Usage
```
1. cd to the root directory (the one containing `server.js`)

2. Run the following in terminal:

npm install
npm start

3. Go to localhost:8080 on any browser
```

